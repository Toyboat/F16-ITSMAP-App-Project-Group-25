<?php
class DBInfo
{
 static $servername = 'localhost';
 static $serverport = '';
 static $username = 'root';
 static $password = '';
 static $database = 'lostandfound';
}

?>